#ifndef INCLUDE_H
 #define INCLUDE_H
	#include <stdlib.h>
	#include <stdio.h>
	#include <time.h>
	#define N 10
	#define NBMAXBUSHIS 12
	#define DEPLACEMENTSMAX 24
	
void save_and_quit(int signal);
void load();
#endif
